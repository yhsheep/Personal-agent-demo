# 参与文澜

文澜是一个本地部署的文献问答与 RAG 评测项目。它不追求覆盖所有文献工作流，也不想做成通用文献管理系统。

欢迎 issue、fork 和 PR，但请理解这是一个维护精力有限的小项目。

## 适合的贡献

- PDF 解析问题：双栏、公式、表格、扫描版、特殊字体；
- 检索质量：Chunk、Top-K、重排、中文提问；
- 评测：补充真实论文用例、失败分析、指标修正；
- 模型接入：新的 OpenAI 兼容服务、Embedding 服务；
- 平台兼容：Windows / macOS / Linux 启动问题；
- 文档与中文文案改进。

## 开发环境

```bash
python -m venv .venv
source .venv/bin/activate        # Windows: .venv\Scripts\activate
pip install -e ".[dev]"
cp .env.example .env
python -m app.cli init-db
python -m app.cli seed
python -m app.cli serve
```

测试不依赖外部 API：

```bash
pytest -q
ruff check app tests
```

## 提交 PR 前

1. 先开 issue 说明要解决的问题，避免大改动方向不一致；
2. 保持改动聚焦，不把无关格式化混进 PR；
3. 新增行为要有测试，至少覆盖核心路径；
4. 不要提交 `.env`、API Key、`data/uploads/`、`data/pgdata/`、运行日志；
5. 不要在测试或示例中加入未公开的论文、个人信息或受限数据。

## 数据与隐私

- 默认只监听 `127.0.0.1`；
- API Key 只从环境变量 / `.env` 读取；
- 示例语料是真实论文元数据 + 生成的摘要笔记，不是原论文全文；
- 请不要把未公开的论文或评审材料提交到公开仓库。

## 新增模型服务

1. 在 `app/providers.py` 增加预设；
2. 确认接口为 OpenAI 兼容的 `/chat/completions` 和/或 `/embeddings`；
3. 在 `.env.example` 和 README 中补充环境变量说明；
4. 用一条真实请求验证 Tool Calling 和流式输出；
5. 在 PR 中说明模型、价格、上下文长度和已知限制。

## 许可

提交的代码默认按 MIT License 贡献。
